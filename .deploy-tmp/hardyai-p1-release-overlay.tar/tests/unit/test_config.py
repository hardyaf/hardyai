from __future__ import annotations

import json
import os
import subprocess
import sys

import pytest


SETTING_NAMES = {
    "MAIN_TOOL_EXECUTION_MODE",
    "MAIN_TOOL_ENABLED_DOMAINS",
    "MAIN_TOOL_ENABLED_OPERATIONS",
    "MAIN_TOOL_MAX_SELECTED_SKILLS",
    "MAIN_TOOL_MAX_STEPS",
    "MAIN_TOOL_MAX_FAILURES",
    "MAIN_TOOL_MAX_IDENTICAL_READ_CALLS",
    "MAIN_TOOL_MAX_OBSERVATION_CHARS",
    "MAIN_TOOL_MAX_TOTAL_OBSERVATION_CHARS",
    "MAIN_TOOL_TIMEOUT_SECONDS",
    "LEGACY_MICRO_ROUTING_ENABLED",
}


def _load_config(overrides: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    environment = {key: value for key, value in os.environ.items() if key not in SETTING_NAMES}
    environment["JARVIS_SKIP_DOTENV"] = "1"
    environment.update(overrides or {})
    return subprocess.run(
        [
            sys.executable,
            "-c",
            (
                "import json; from app.config import settings; "
                "print(json.dumps({"
                "'mode': settings.main_tool_execution_mode, "
                "'domains': settings.main_tool_enabled_domains, "
                "'operations': settings.main_tool_enabled_operations, "
                "'selected': settings.main_tool_max_selected_skills, "
                "'steps': settings.main_tool_max_steps, "
                "'failures': settings.main_tool_max_failures, "
                "'repeats': settings.main_tool_max_identical_read_calls, "
                "'observation': settings.main_tool_max_observation_chars, "
                "'total_observation': settings.main_tool_max_total_observation_chars, "
                "'timeout': settings.main_tool_timeout_seconds, "
                "'legacy_micro': settings.legacy_micro_routing_enabled}))"
            ),
        ],
        check=False,
        capture_output=True,
        text=True,
        env=environment,
    )


def test_main_tool_settings_have_inert_locked_defaults() -> None:
    completed = _load_config()

    assert completed.returncode == 0, completed.stderr
    assert json.loads(completed.stdout) == {
        "mode": "off",
        "domains": [],
        "operations": [],
        "selected": 3,
        "steps": 8,
        "failures": 2,
        "repeats": 2,
        "observation": 8000,
        "total_observation": 24000,
        "timeout": 120,
        "legacy_micro": True,
    }


def test_main_tool_operation_allowlist_preserves_exact_identifiers() -> None:
    completed = _load_config(
        {
            "MAIN_TOOL_ENABLED_DOMAINS": "email,calendar",
            "MAIN_TOOL_ENABLED_OPERATIONS": "email.query_messages,calendar.query_events",
        }
    )

    assert completed.returncode == 0, completed.stderr
    settings = json.loads(completed.stdout)
    assert settings["domains"] == ["email", "calendar"]
    assert settings["operations"] == ["email.query_messages", "calendar.query_events"]
    assert "email.query" not in settings["operations"]


@pytest.mark.parametrize(
    ("name", "value"),
    [
        ("MAIN_TOOL_EXECUTION_MODE", "observe"),
        ("MAIN_TOOL_ENABLED_DOMAINS", "email,email"),
        ("MAIN_TOOL_ENABLED_DOMAINS", "Email"),
        ("MAIN_TOOL_ENABLED_OPERATIONS", "email.query_messages,email.query_messages"),
        ("MAIN_TOOL_ENABLED_OPERATIONS", "email"),
        ("MAIN_TOOL_MAX_SELECTED_SKILLS", "4"),
        ("MAIN_TOOL_MAX_STEPS", "0"),
        ("MAIN_TOOL_MAX_FAILURES", "many"),
        ("MAIN_TOOL_MAX_IDENTICAL_READ_CALLS", "-1"),
        ("MAIN_TOOL_MAX_OBSERVATION_CHARS", "0"),
        ("MAIN_TOOL_MAX_TOTAL_OBSERVATION_CHARS", "0"),
        ("MAIN_TOOL_TIMEOUT_SECONDS", "0"),
        ("LEGACY_MICRO_ROUTING_ENABLED", "sometimes"),
    ],
)
def test_main_tool_settings_reject_invalid_values(name: str, value: str) -> None:
    completed = _load_config({name: value})

    assert completed.returncode != 0
    assert name in completed.stderr
