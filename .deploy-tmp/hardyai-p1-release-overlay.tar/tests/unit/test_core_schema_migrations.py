from __future__ import annotations

import json
import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest

from app.db.migrations import (
    LATEST_SCHEMA_VERSION,
    evaluate_schema_reader_compatibility,
    initialize_schema,
)
from scripts.manage_database import reader_check


def _newer_database(
    path: Path,
    *,
    version: int = 8,
    rows: tuple[tuple[int, int, str], ...] = ((8, 7, "additive"),),
    create_compatibility_table: bool = True,
) -> None:
    connection = sqlite3.connect(path)
    try:
        connection.execute("CREATE TABLE canary (value TEXT NOT NULL)")
        connection.execute("INSERT INTO canary VALUES ('unchanged')")
        if create_compatibility_table:
            connection.execute(
                """
                CREATE TABLE schema_reader_compatibility (
                    schema_version INTEGER NOT NULL,
                    minimum_reader_version INTEGER NOT NULL,
                    change_class TEXT NOT NULL
                )
                """
            )
            connection.executemany(
                "INSERT INTO schema_reader_compatibility VALUES (?, ?, ?)",
                rows,
            )
        connection.execute(f"PRAGMA user_version = {version}")
        connection.commit()
    finally:
        connection.close()


def test_current_core_schema_initializes_at_reader_version(tmp_path: Path) -> None:
    connection = sqlite3.connect(tmp_path / "current.db")
    connection.row_factory = sqlite3.Row
    try:
        assert initialize_schema(connection) == LATEST_SCHEMA_VERSION == 7
        assert evaluate_schema_reader_compatibility(connection).compatible is True
    finally:
        connection.close()


def test_p1_reader_accepts_complete_additive_newer_chain_without_migration(tmp_path: Path) -> None:
    path = tmp_path / "newer.db"
    _newer_database(
        path,
        version=9,
        rows=((8, 7, "additive"), (9, 6, "additive")),
    )
    connection = sqlite3.connect(path)
    try:
        assert initialize_schema(connection) == 9
        assert connection.execute("PRAGMA user_version").fetchone()[0] == 9
        assert connection.execute("SELECT value FROM canary").fetchone()[0] == "unchanged"
    finally:
        connection.close()


@pytest.mark.parametrize(
    ("version", "rows", "create_table", "reason"),
    [
        (8, (), False, "compatibility_table_missing"),
        (9, ((8, 7, "additive"),), True, "compatibility_row_missing"),
        (8, ((8, 7, "destructive"),), True, "change_not_additive"),
        (8, ((8, 8, "additive"),), True, "minimum_reader_too_new"),
    ],
)
def test_p1_reader_fails_closed_for_unproven_newer_schema(
    tmp_path: Path,
    version: int,
    rows: tuple[tuple[int, int, str], ...],
    create_table: bool,
    reason: str,
) -> None:
    path = tmp_path / f"denied-{reason}.db"
    _newer_database(path, version=version, rows=rows, create_compatibility_table=create_table)
    connection = sqlite3.connect(path)
    try:
        decision = evaluate_schema_reader_compatibility(connection)
        assert decision.compatible is False
        assert decision.reason == reason
        with pytest.raises(RuntimeError, match="newer than supported"):
            initialize_schema(connection)
        assert connection.execute("PRAGMA user_version").fetchone()[0] == version
    finally:
        connection.close()


def test_core_reader_check_is_immutable_and_emits_only_fixed_fields(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    path = tmp_path / "reader.db"
    _newer_database(path)
    before = path.stat().st_mtime_ns

    assert reader_check(path) == 0
    output = json.loads(capsys.readouterr().out)
    assert output == {
        "reason": "additive_reader_bridge",
        "result": "compatible",
        "version": 8,
    }
    assert path.stat().st_mtime_ns == before
    assert not Path(f"{path}-wal").exists()
    assert not Path(f"{path}-shm").exists()

    completed = subprocess.run(
        [
            sys.executable,
            "scripts/manage_database.py",
            "reader-check",
            "--source",
            str(path),
        ],
        check=False,
        capture_output=True,
        text=True,
    )
    assert completed.returncode == 0, completed.stderr
    assert json.loads(completed.stdout) == output
