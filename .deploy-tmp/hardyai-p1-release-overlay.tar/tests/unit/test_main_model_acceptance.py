from __future__ import annotations

from pathlib import Path

from scripts.benchmark_main_models import evaluate_case, load_cases


LEGACY_LATENCY_IDS = {
    "conversation_stable_fact",
    "turn_general_conversation",
    "turn_authorized_list_add",
    "turn_missing_switch_clarifies",
    "turn_unauthorized_action_fails_closed",
    "repair_authorized_list_add",
}

REASONING_TOOL_IDS = {
    "tool_email_arbitrary_interval_last_3_days",
    "tool_email_exact_date",
    "tool_iterative_observation",
    "tool_missing_argument_clarification",
    "tool_unauthorized_refusal",
    "tool_approval_pause_resume",
    "tool_repeat_detection",
    "tool_partial_completion",
}


def test_main_acceptance_manifest_is_valid_and_has_safety_case() -> None:
    cases = load_cases(Path("benchmarks/models/main_acceptance_cases.json"))

    assert {case["kind"] for case in cases} == {"conversation", "turn_decision", "repair"}
    assert any(case.get("safety_critical") is True for case in cases)


def test_main_acceptance_manifest_has_locked_legacy_and_deferred_reasoning_groups() -> None:
    cases = load_cases(Path("benchmarks/models/main_acceptance_cases.json"))
    legacy = {
        str(case["id"])
        for case in cases
        if case.get("benchmark_group") == "legacy_latency_v1"
    }
    reasoning = [
        case for case in cases if case.get("benchmark_group") == "reasoning_tools_v1"
    ]

    assert legacy == LEGACY_LATENCY_IDS
    assert {str(case["id"]) for case in reasoning} == REASONING_TOOL_IDS
    assert all(case.get("execution_enabled") is False for case in reasoning)
    assert all(str(case.get("owning_phase") or "").startswith("P") for case in reasoning)


def test_main_acceptance_evaluator_requires_expected_contract_labels() -> None:
    case = {
        "id": "typed-list",
        "kind": "turn_decision",
        "text": "synthetic",
        "context": {},
        "expect": {"mode": "execute_action", "intent": "lists.add_item"},
        "max_seconds": 5.0,
    }
    valid = {
        "mode": "execute_action",
        "intent": "lists.add_item",
        "confidence": 0.95,
        "reasoning": "ready",
        "entities": {"list_name": "errands", "item_text": "coffee"},
        "missing_fields": [],
        "message": "",
        "question": None,
        "source": "backend",
    }

    accepted = evaluate_case(case, valid, seconds=1.0)
    rejected = evaluate_case(case, {**valid, "intent": "lists.create_list"}, seconds=1.0)

    assert accepted["passed"] is True
    assert rejected["passed"] is False


def test_main_acceptance_evaluator_applies_latency_gate_without_output_content() -> None:
    case = {
        "id": "conversation",
        "kind": "conversation",
        "text": "synthetic",
        "context": {},
        "expect": {"nonempty": True},
        "max_seconds": 2.0,
    }

    result = evaluate_case(case, "valid private answer", seconds=3.0)

    assert result["contract_valid"] is True
    assert result["latency_ok"] is False
    assert "valid private answer" not in str(result)
