#!/usr/bin/env python3
"""Verify document durable-job payloads contain only approved opaque fields."""

from __future__ import annotations

import argparse
import json
import sqlite3
from collections import Counter
from pathlib import Path


ALLOWED_KEYS = {"document_id", "intake_id", "sha256"}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("database", type=Path)
    args = parser.parse_args()
    connection = sqlite3.connect(f"file:{args.database.resolve()}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    try:
        rows = connection.execute(
            """
            SELECT status, payload_json
            FROM durable_jobs
            WHERE job_type = 'document.archive.v1'
            """
        ).fetchall()
    finally:
        connection.close()
    if not rows:
        raise RuntimeError("no document archive jobs were found")
    statuses: Counter[str] = Counter()
    for row in rows:
        payload = json.loads(row["payload_json"])
        if not isinstance(payload, dict) or set(payload) != ALLOWED_KEYS:
            raise RuntimeError("a document job contains an unapproved payload shape")
        if not all(isinstance(payload[key], str) and payload[key] for key in ALLOWED_KEYS):
            raise RuntimeError("a document job contains an invalid opaque reference")
        if len(payload["sha256"]) != 64:
            raise RuntimeError("a document job contains an invalid SHA-256")
        statuses[str(row["status"])] += 1
    print(json.dumps({"status": "passed", "jobs": len(rows), "states": dict(statuses)}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
